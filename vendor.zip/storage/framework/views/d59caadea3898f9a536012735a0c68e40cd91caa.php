<?php $__env->startSection('contents'); ?>
  <div class="page-header card">
                                          <div class="card-block">
                                                      <ul class="breadcrumb-title ">
                                                  <li class="breadcrumb-item">
                                                      <a href="<?php echo e(url('/')); ?>"> <i class="fa fa-home"></i> </a>
                                                  </li>
                                                  <li class="breadcrumb-item"><a href="#!">Installment</a>
                                                          </li>
                                                          <li class="breadcrumb-item"><a href="#!">Monthly Installment List</a>
                                                          </li>
                                              </ul>
                                          </div>
                                      </div>

<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">
          <div class="row">
<div class="col-lg-12">
  <?php if(session('status')): ?>
      <div class="alert alert-success">
          <?php echo e(session('status')); ?>

      </div>
  <?php endif; ?>
<?php
  // echo "<pre>";
  // print_r($customers);
  // echo "</pre>";
  $i =1;
?>
  <div class="card-block table-border-style">
                                    <div class="table-responsive">
                                        <table id="" class="table">
                                            <thead>
                                                <tr>
                                                    <th>Months</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                              <?php
                                                 $start_month = $months_all['0'];
                                                 $month_number =$months;
                                              $month_number;
                                              ?>

<?php for($i=0; $i < $month_number; $i++): ?>

  <tr>

      <td>
<?php if($start_month == 1): ?>
  <?php echo e('January'); ?>

<?php elseif($start_month == 2): ?>
  <?php echo e('February'); ?>

<?php elseif($start_month == 03): ?>
  <?php echo e('March'); ?>


<?php elseif($start_month == 4): ?>
  <?php echo e('April'); ?>


<?php elseif($start_month == 5): ?>
  <?php echo e('May'); ?>


<?php elseif($start_month == 6): ?>
  <?php echo e('June'); ?>


<?php elseif($start_month == 7): ?>
  <?php echo e('July'); ?>


<?php elseif($start_month == 8): ?>
  <?php echo e('August'); ?>


<?php elseif($start_month == 9): ?>
  <?php echo e('September'); ?>


<?php elseif($start_month == 10): ?>
  <?php echo e('October'); ?>


<?php elseif($start_month == 11): ?>
  <?php echo e('November'); ?>


<?php elseif($start_month == 12): ?>
  <?php echo e('Decebemer'); ?>


<?php elseif($start_month == 13): ?>
    <?php echo e('January'); ?>

  <?php elseif($start_month == 14): ?>
    <?php echo e('February'); ?>

  <?php elseif($start_month == 15): ?>
    <?php echo e('March'); ?>


  <?php elseif($start_month ==16): ?>
    <?php echo e('April'); ?>


  <?php elseif($start_month == 17): ?>
    <?php echo e('May'); ?>


  <?php elseif($start_month == 18): ?>
    <?php echo e('June'); ?>


  <?php elseif($start_month == 19): ?>
    <?php echo e('July'); ?>


  <?php elseif($start_month == 20): ?>
    <?php echo e('August'); ?>


  <?php elseif($start_month == 21): ?>
    <?php echo e('September'); ?>


  <?php elseif($start_month == 22): ?>
    <?php echo e('October'); ?>


  <?php elseif($start_month == 23): ?>
    <?php echo e('November'); ?>


  <?php elseif($start_month == 24): ?>
    <?php echo e('Decebemer'); ?>


<?php elseif($start_month == 25): ?>
    <?php echo e('January'); ?>

  <?php elseif($start_month == 26): ?>
    <?php echo e('February'); ?>

  <?php elseif($start_month == 27): ?>
    <?php echo e('March'); ?>


  <?php elseif($start_month ==28): ?>
    <?php echo e('April'); ?>


  <?php elseif($start_month == 29): ?>
    <?php echo e('May'); ?>


  <?php elseif($start_month == 30): ?>
    <?php echo e('June'); ?>


  <?php elseif($start_month == 31): ?>
    <?php echo e('July'); ?>


  <?php elseif($start_month == 32): ?>
    <?php echo e('August'); ?>


  <?php elseif($start_month == 33): ?>
    <?php echo e('September'); ?>


  <?php elseif($start_month == 34): ?>
    <?php echo e('October'); ?>


  <?php elseif($start_month == 35): ?>
    <?php echo e('November'); ?>


  <?php elseif($start_month == 36): ?>
    <?php echo e('Decebemer'); ?>


<?php elseif($start_month == 37): ?>
    <?php echo e('January'); ?>

  <?php elseif($start_month == 38): ?>
    <?php echo e('February'); ?>

  <?php elseif($start_month == 39): ?>
    <?php echo e('March'); ?>


  <?php elseif($start_month == 40): ?>
    <?php echo e('April'); ?>


  <?php elseif($start_month == 41): ?>
    <?php echo e('May'); ?>


  <?php elseif($start_month == 42): ?>
    <?php echo e('June'); ?>


  <?php elseif($start_month == 43): ?>
    <?php echo e('July'); ?>


  <?php elseif($start_month == 44): ?>
    <?php echo e('August'); ?>


  <?php elseif($start_month == 45): ?>
    <?php echo e('September'); ?>


  <?php elseif($start_month == 46): ?>
    <?php echo e('October'); ?>


  <?php elseif($start_month == 47): ?>
    <?php echo e('November'); ?>


  <?php elseif($start_month == 48): ?>
    <?php echo e('Decebemer'); ?>

<?php endif; ?>

        
      </td>
      <td><?php echo e($installmentstatus_details->per_month_amount); ?></td>
      <td>
         

        <?php if($installmentstatus_details->total_months == $installmentstatus_details->total_months_remaining ): ?>
          <a href="<?php echo e(url('/installment/months/show/'.$installmentstatus_details->id .'/'.$installmentstatus_details->total_months_remaining)); ?>" >
            <div class="label-main">
              <label class="label label-primary">Pending</label>
            </div>
          </a>
        <?php elseif($installmentstatus_details->total_months > $installmentstatus_details->total_months_remaining &&  $installmentstatus_details->total_months_remaining ==0 ): ?>
          <a href="<?php echo e(url('/installment/months/show/')); ?>" >
            <div class="label-main">
              <label class="label label-info">Due</label>
            </div>
          </a>
        <?php else: ?>
          <a href="<?php echo e(url('/installment/months/show/')); ?>" >
            <div class="label-main">
              <label class="label label-success">Paid</label>
            </div>
          </a>
        <?php endif; ?>

      </td>
  </tr>
  <?php
    $start_month++;
  ?>
<?php endfor; ?>



                                            </tbody>
                                        </table>
                                        <h1>
                                          <a href="<?php echo e(url('/installment/months/show/update/'.$insert_installment_id."/".$extragetid)); ?>">
                                            To Update
                                          </a>
                                        </h1>
                                    </div>
                                </div>

          </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_here'); ?>

   <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
   <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>

   <script type="text/javascript">
   $(document).ready(function() {
     $('#table_customer').DataTable( {
         "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
         dom: 'Bfrtip',
         buttons: [
             {
                 extend: 'copyHtml5',
                 text: 'Reports',
                 exportOptions: {
                     columns: [  0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15]
                 }
             },
             {
                 extend: 'excelHtml5',
                 text: 'Print',
                 exportOptions: {
                   columns: [ 0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15]
                 }
             },
             {
                 extend: 'pdfHtml5',
                 text: 'Export',
                 exportOptions: {
                     columns: [1, 2, 3,4,5,12]
                 }
             }
         ]
     } );
   });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>