<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Installmentmonth extends Model
{
    //
}
