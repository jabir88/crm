 <?php $__env->startSection('contents'); ?>
<div class="page-header card">
  <div class="card-block">
    <ul class="breadcrumb-title ">
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('/')); ?>"> <i class="fa fa-home"></i> </a>
      </li>
      <li class="breadcrumb-item"><a href="#!">Installment</a>
      </li>
      <li class="breadcrumb-item"><a href="#!">Edit Installment</a>
      </li>
    </ul>
  </div>
</div>


<div class="main-body">
  <div class="page-wrapper">

    <div class="page-body">
      <div class="row">
        <div class="col-lg-12">
          <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
          <?php endif; ?>

          <form action="<?php echo e(route('installment.submit.chart')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="email_hosting_years">Company Name</label>
              <div class="col-sm-10">
                <?php
                  echo "<pre>";
                  // if ($installment_details->select_company_name == $customer_details[0]->company_name) {
                  //   return "yes";
                  // }
                  // print_r($installment_details->select_company_name);
                  // print_r($customer_details[0]);
                  echo "</pre>";
                ?>
                <select id="email_hosting_years" name="select_company_name" class="form-control">
                  <option value="" selected>Select Company Name</option>



                  <?php $__currentLoopData = $customer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!empty($customer_detail->company_name)): ?>
                    <option value="<?php echo e($installment_details->select_company_name); ?>" <?php if($installment_details->select_company_name == $customer_detail->company_name): ?> <?php echo e('selected'); ?> <?php endif; ?> ><?php echo e($installment_details->select_company_name); ?>

                    </option>

                  <option value="<?php echo e($customer_detail->company_name); ?>"><?php echo e($customer_detail->company_name); ?></option>
                  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>
                
                <button type="button" class="btn btn-mat btn-info " data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Other</button>

              </div>
            </div>



            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="quotation">Quotation</label>
              <div class="col-sm-10">
                <input type="text" id="quotation" class="form-control" name="quotation" value="<?php echo e($installment_details->quotation); ?>" placeholder="Quotation">
                <input type="hidden" id="" class="form-control" name="my_id" value="<?php echo e($installment_details->id); ?>">
              </div>
            </div>



            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="invoice">Invoice</label>
              <div class="col-sm-10">
                <input type="text" id="invoice" class="form-control" name="invoice" value="<?php echo e($installment_details->invoice); ?>" placeholder="Invoice">

              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="services">Services</label>
              <div class="col-sm-10">
                <textarea name="services" id="services" rows="5" cols="5" class="form-control" placeholder="Services"><?php echo e($installment_details->services); ?></textarea>
              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="total_amount">Total Amount</label>
              <div class="col-sm-10">
                <input type="number" id="total_amount" class="form-control" name="total_amount" value="<?php echo e($installment_details->total_amount); ?>" placeholder="$ Total Amount"> <?php if($errors->has('total_amount')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('total_amount')); ?></strong>
                </span> <?php endif; ?>
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="installment_duration">Installment Durations</label>
              <div class="col-sm-10">

                <select id="installment_duration" name="installment_duration" class="form-control">
                  <option value="1" <?php if($installment_details->installment_duration == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>>Monthly
                  </option>
                  <option value="0" <?php if($installment_details->installment_duration == 0): ?> <?php echo e('selected'); ?> <?php endif; ?>>Yearly
                  </option>
                </select>
              </div>
            </div>

            

            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="installment_unit">Total Installment Unit</label>
              <div class="col-sm-10">
                <input type="number" id="installment_unit" class="form-control" name="installment_unit" value="<?php echo e($installment_details->installment_unit); ?>" placeholder="Total Installment Unit"> <?php if($errors->has('installment_unit')): ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('installment_unit')); ?></strong>
                    </span> <?php endif; ?>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="per_unit_repayment">Per Unit Repayment</label>
              <div class="col-sm-10">
                <input type="number" id="per_unit_repayment" class="form-control" name="per_unit_repayment" value="<?php echo e($installment_details->per_unit_repayment); ?>" placeholder="$ Per Years Repayment"> <?php if($errors->has('per_unit_repayment')): ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('per_unit_repayment')); ?></strong>
                    </span> <?php endif; ?>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="">Start Date and End Date</label>
              <div class="col-sm-5">
                <div class='input-group date datepicker'>
                  <input type='text' class="form-control" name="installment_start_date" value="<?php echo e($installment_details->installment_start_date); ?>" placeholder="Start Date" /> <?php if($errors->has('installment_start_date')): ?>
                  <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('installment_start_date')); ?></strong>
                                </span> <?php endif; ?>
                  <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                  </span>
                </div>
              </div>
              <div class="col-sm-5">
                <div class='input-group date datepicker'>
                  <input type='text' class="form-control" name="installment_end_date" value="<?php echo e($installment_details->installment_end_date); ?>" placeholder="End Date" /> <?php if($errors->has('installment_end_date')): ?>
                  <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('installment_end_date')); ?></strong>
                                </span> <?php endif; ?>
                  <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                  </span>
                </div>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-sm-12">
                <div class="card-block table-border-style">
                  <div class="table-responsive">
                     

                    

                  
                    <table id="test-table" class="table table-condensed">
                      <thead>
                        <tr>
                          <th>Mothn</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Balance</th>

                        </tr>
                      </thead>
                      <tbody id="test-body">
                        <?php $__currentLoopData = $installment_details->Chart_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr id="row0">
                          <td>

                            <select id="seleted_month_name" name="seleted_month_name[]" class="form-control">
                               <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($month['id']); ?>" <?php if($v->seleted_month_name == $month['id']): ?> <?php echo e('selected'); ?> <?php endif; ?> ><?php echo e($month['month_name']); ?></option>

                              <option value="<?php echo e($month['id']); ?>"><?php echo e($month['month_name']); ?></option>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                             
                          </td>
                          <td>
                            <input name='amount[]' value="<?php echo e($v->amount); ?>" type='number' class='form-control input-md' /> 
                          </td>
                          <td>
                            <select id="email_hosting_years" name="status[]" class="form-control">
                              


                              <option value="0" <?php if($v->status == 0): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e("Pending"); ?></option>

                              <option value="1" <?php if($v->status == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e("Due"); ?></option>

                              <option value="2" <?php if($v->status == 2): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e("Paid"); ?></option>



                            </select>
                            
                          </td>
                          <td>
                            <input name='balance[]' value="<?php echo e($v->balance); ?>" type='number' class='form-control input-md' /> 
                          </td>
                          
                            
                            
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-2 col-form-label"> </label>
              <div class="col-sm-10">
                <button type="submit" class="btn btn-out-dotted btn-primary btn-square">Edit Installment Accounts</button>
              </div>
            </div>



          </form>
        </div>
      </div>
    </div>

  </div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-body">
        <form action="<?php echo e(route('company.add')); ?>"  method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label class="col-sm-2 col-form-label" for="company_name">Company Name</label>
              <div class="col-sm-10">
                  <input type="text" id="company_name" class="form-control" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="Company Name">
              </div>
          </div>


          <div class="form-group">
              <label class="col-sm-2 col-form-label" for="customer_name">Customer Name</label>
              <div class="col-sm-10">
                  <input type="text" id="customer_name" class="form-control" name="customer_name" value="<?php echo e(old('customer_name')); ?>" placeholder="Customer Name">
                  <?php if($errors->has('customer_name')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('customer_name')); ?></strong>
                      </span>
                  <?php endif; ?>
              </div>

            </div>

          <div class="form-group">
              <label class="col-sm-2 col-form-label" for="contact">Contact</label>
              <div class="col-sm-10">
                  <input type="text" id="contact" class="form-control" name="contact" value="<?php echo e(old('contact')); ?>" placeholder="Contact">
                  <?php if($errors->has('contact')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('contact')); ?></strong>
                      </span>
                  <?php endif; ?>
              </div>
          </div>


          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Company</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('script_here'); ?>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>

<script type="text/javascript">
  $(document).on("click", "#add-row", function() {
    var new_row = $('#row0').clone('#row0');
    // var new_row = '<tr id="row' + row + '"><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="to_value' + row + '" type="text" class="form-control" /></td><td><input class="delete-row btn btn-primary" type="button" value="Delete" /></td></tr>';
    // var new_row = '<tr id="row' + row + '"><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="from_value' + row + '" type="text" class="form-control" /></td><td><input name="to_value' + row + '" type="text" class="form-control" /></td><td><input class="delete-row btn btn-primary" type="button" value="Delete" /></td></tr>';
    // alert(new_row);
    new_row.find('input').val('');
    $('#test-body').append(new_row);
    row++;
    return false;
  });
  $("#add-row").click(function() {
    $("#row1").removeClass("d-none");
  });

  // Remove criterion
  $(document).on("click", ".delete-row", function() {
     // alert("deleting row#");
    if (row > 1) {
      $(this).closest('tr').remove();
      row--;
    }
    return false;
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>