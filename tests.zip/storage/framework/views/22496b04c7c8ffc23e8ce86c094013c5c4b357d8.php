 <?php $__env->startSection('contents'); ?>
<div class="page-header card">
  <div class="card-block">
    <ul class="breadcrumb-title ">
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('/')); ?>"> <i class="fa fa-home"></i> </a>
      </li>
      <li class="breadcrumb-item"><a href="#!">Billing Payment</a>
      </li>
      <li class="breadcrumb-item"><a href="#!">Add Billing</a>
      </li>
    </ul>
  </div>
</div>


<div class="main-body">
  <div class="page-wrapper">

    <div class="page-body">
      <div class="row">
        <div class="col-lg-12">
          <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
          <?php endif; ?>

          <form action="<?php echo e(route('add.accounts.submit')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="email_hosting_years">Company Name</label>
              <div class="col-sm-10">


                <select id="email_hosting_years" name="select_company_name" class="form-control ">
                  <option value=" " selected>Select Company Name</option>



                   <?php $__currentLoopData = $customer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!empty($customer_detail->company_name)): ?>

                  <option value="<?php echo e($customer_detail->company_name); ?>"><?php echo e($customer_detail->company_name); ?></option>
                  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>
                 
                <button type="button" class="btn btn-mat btn-info " data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Other</button>
              </div>

            </div>

            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="quotation">Quotation</label>
              <div class="col-sm-10">
                <input type="text" id="quotation" class="form-control" name="quotation" value="<?php echo e(old('quotation')); ?>" placeholder="Quotation">
              </div>
            </div>



            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="invoice">Invoice</label>
              <div class="col-sm-10">
                <input type="text" id="invoice" class="form-control" name="invoice" value="<?php echo e(old('invoice')); ?>" placeholder="Invoice">

              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="services">Services</label>
              <div class="col-sm-10">
                <textarea name="services" id="services" rows="5" cols="5" class="form-control" placeholder="Services"><?php echo e(old('services')); ?></textarea>
              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="total_amount">Total Amount</label>
              <div class="col-sm-10">
                <input type="number" id="total_amount" class="form-control" name="total_amount" value="<?php echo e(old('total_amount')); ?>" placeholder="$ Total Amount"> <?php if($errors->has('total_amount')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('total_amount')); ?></strong>
                </span> <?php endif; ?>
              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="paid">Paid </label>
              <div class="col-sm-10">
                <input type="number" id="paid" class="form-control" name="paid" value="<?php echo e(old('paid')); ?>" placeholder="$ Paid "> <?php if($errors->has('paid')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('paid')); ?></strong>
                </span> <?php endif; ?>
              </div>
            </div>



            

            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="balance">Balance</label>
              <div class="col-sm-10">
                <input type="number" id="balance" onClick="SubtractionBy()" class="form-control" name="balance" value="<?php echo e(old('balance')); ?>" placeholder="$ Balance">
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-2 col-form-label" for="remark">Remark</label>
              <div class="col-sm-10">
                <textarea name="remark" id="remark" rows="5" cols="5" class="form-control" placeholder="Remark"><?php echo e(old('remark')); ?></textarea>
              </div>
            </div>


            <div class="form-group row">
              <label class="col-sm-2 col-form-label"> </label>
              <div class="col-sm-10">
                <button type="submit" class="btn btn-out-dotted btn-primary btn-square">Add Billing Accounts</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <div class="modal-body">
        <form action="<?php echo e(route('company.add')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="col-sm-2 col-form-label" for="company_name">Company Name</label>
            <div class="col-sm-10">
              <input type="text" id="company_name" class="form-control" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="Company Name">
            </div>
          </div>


          <div class="form-group">
            <label class="col-sm-2 col-form-label" for="customer_name">Customer Name</label>
            <div class="col-sm-10">
              <input type="text" id="customer_name" class="form-control" name="customer_name" value="<?php echo e(old('customer_name')); ?>" placeholder="Customer Name"> <?php if($errors->has('customer_name')): ?>
              <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('customer_name')); ?></strong>
                      </span> <?php endif; ?>
            </div>

          </div>

          <div class="form-group">
            <label class="col-sm-2 col-form-label" for="contact">Contact</label>
            <div class="col-sm-10">
              <input type="text" id="contact" class="form-control" name="contact" value="<?php echo e(old('contact')); ?>" placeholder="Contact"> <?php if($errors->has('contact')): ?>
              <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('contact')); ?></strong>
                      </span> <?php endif; ?>
            </div>
          </div>


          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Company</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> <?php $__env->startSection('script_here'); ?>
<script>
  $(document).ready(function() {
    $('#email_hosting_years').select2();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>