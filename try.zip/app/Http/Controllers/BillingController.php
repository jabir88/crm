<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\Billing;
use App\Installment;
use App\Installmentstatus;
use Carbon\Carbon;
use DB;
use App\Month;

class BillingController extends Controller
{
    public function billing_add()
    {
        $customer_details =    Customer::all();
        return view('admin.billing.billing_add', compact('customer_details'));
    }

    public function billing_add_sub(Request $req)
    {
        $this->validate($req, [
     'total_amount'=> 'required|numeric',
   ], [
     'total_amount.required'=>"Please Enter Total Amount.",
     'total_amount.numeric'=>"Please Enter Only Number.",
   ]);

        $insert=  Billing::insert([
        'select_company_name'=>$req->select_company_name,
        'quotation'=>$req->quotation,
        'invoice'=>$req->invoice,
        'services'=>$req->services,
        'total_amount'=>$req->total_amount,
        'paid'=>$req->paid,
        'balance'=>$req->balance,
        'remark'=>$req->remark,
        'created_at'=>Carbon::now(),
      ]);
        if ($insert) {
            return redirect()->back()->with('status', 'Accounts Add Successfully !');
        } else {
            return redirect()->back();
        }
    }
    public function installment_add()
    {
        $customer_details =    Customer::all();
        return view('admin.installment.installment_add', compact('customer_details'));
    }

    public function installment_submit(Request $req)
    {
        $this->validate($req, [
          'total_amount'=> 'required|numeric',
          'installment_unit'=> 'required|numeric',
          'installment_start_date'=> 'required',
'installment_end_date'=> 'required',
        ], [
          'total_amount.required'=>"Please Enter Total Amount.",
          'total_amount.numeric'=>"Please Enter Only Number.",
          'installment_unit.required'=>"Please Enter Total Installment Unit.",
          'installment_unit.numeric'=>"Please Enter Only Number.",
        ]);
        $insert_installment_id = Installment::insertGetId([
        'installment_end_date'=>$req->installment_end_date,
        'installment_start_date'=>$req->installment_start_date,
        'installment_unit'=>$req->installment_unit,
        'invoice'=>$req->invoice,
        'per_unit_repayment'=>$req->per_unit_repayment,
        'quotation'=>$req->quotation,
        'select_company_name'=>$req->select_company_name,
        'installment_duration'=>$req->installment_duration,
        'services'=>$req->services,
        'total_amount'=>$req->total_amount,
        'created_at'=>carbon::now(),

        ]);


        // return $req->all();

        $installment_start_date = $req->installment_start_date;
        $installment_end_date = $req->installment_end_date;
        $installment_start_date2 =   $installment_start_date." 00:00:00";
        $installment_end_date2 =   $installment_end_date." 00:00:00";

        $actual_start_at = Carbon::parse($installment_start_date2);
        $actual_end_at   = Carbon::parse($installment_end_date2);
        $months            = $actual_end_at->diffInMonths($actual_start_at, true);

        $arry = explode("-", $installment_start_date);

        $months_all= Month::all();
        if ($months_all[0]= $arry[1]) {
            $i = $months_all[0];
        }

        $months=  $months;
        if ($months ==0) {
            $months = $months + 1;
        }
        // $total_amount = $req->total_amount;
        $total_amount = $req->total_amount;
        if ($months !=0) {
            $per_month_amount = $total_amount/$months ;
        } else {
            $per_month_amount = $total_amount/1;
        }
        // return $per_month_amount;
        $insert_id = Installmentstatus::insertGetId([

        'total_months' =>$months,
        'per_month_amount' =>$per_month_amount,
        'total_months_remaining' =>$months,
        'created_at' =>Carbon::now(),
      ]);
        // return $i;
        // //
        $extragetid =  DB::table('extras')->insertGetId([
          'installment_insert_id' =>$insert_id,
          'months' => $months,
          'i' =>$i,
        ]);

        // return $extragetid;
        // return redirect('installment/months/show/'.$extragetid);

        //


        // return back();
        $installmentstatus_details =  Installmentstatus::where('id', $insert_id)->first();
        return view('admin.installment.installment_months', compact('months', 'insert_installment_id', 'extragetid', 'installmentstatus_details', 'i', 'months_all'));
    }
    // return $arry;
    // return $arry[1];
    // if($months_all[]=)
    // if ($arry[1] > 12) {
    //     $i =1;
    // }

    // return $months;


    // foreach ($i as $) {
    //     return $month;
    // }
    // }
    // for ($i; $i <= 12 ; $i++) {
    // }

    // return $months_all;
    // return $arry[1];


    public function installment_months_show($id, $remain)
    {
        $month_update =    $remain-1;
        Installmentstatus::where('id', $id)->update([
        'total_months_remaining' => $month_update,
      ]);
        return redirect()->route('installment.all');
        // return back();
        // $months_all=  Month::get();
        // return $months_all[0];
        // $installmentstatus_details = Installmentstatus::where('id', $insert_id)->first();
        // $extra_all = DB::table('extras')->where('id', $id)->first();
        // $extra_all->installment_insert_id;
        // $installmentstatus_details =  Installmentstatus::where('id', $extra_all->installment_insert_id)->first();
        // $months = $extra_all->months;
        // $i = $extra_all->i;
        // return view('admin.installment.installment_months2', compact('months', 'installmentstatus_details', 'i', 'months_all'));

        // $months_all=  DB::table('months')->get();
        // if ($months_all[0]= $arry[1]) {
        //     $i = $months_all[0];
        // }
        //
        // $months=  $months;
        // $months_remaining=  $months_remaining;
        // $installmentstatus_details = Installmentstatus::where('id', $id)->first();
        // return view('admin.installment.installment_months2', compact('months', 'installmentstatus_details', 'i', 'months_remaining', 'months_all'));
    }




    public function status_update($id, $months_remaining)
    {
        $month_update =    $months_remaining-1;
        Installmentstatus::where('id', $id)->update([
          'total_months_remaining' => $month_update,
        ]);
        return redirect('installment.all');
    }


    public function installment_months_update($id, $extragetid)
    {
        $all_installment = Installment::where('id', $id)->get();

        $all_installment2=   $all_installment[0]->installment_start_date;
        $convert = explode("-", $all_installment2);
        $convert =$convert[1];

        $extra_all = DB::table('extras')->where('id', $extragetid)->first();
        $extra_all->installment_insert_id;
        $installmentstatus_details =  Installmentstatus::where('id', $extra_all->installment_insert_id)->first();
        $months = $extra_all->months;
        $i = $extra_all->i;
        return view('admin.installment.installment_months2', compact('months', 'convert', 'insert_installment_id', 'installmentstatus_details', 'i', 'months_all'));
    }
    // code...

    public function installment_all()
    {
        $installment_all =  Installment::get();

        return view('admin.installment.installment_all', compact('installment_all'));
    }
}
