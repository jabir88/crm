<?php $__env->startSection('contents'); ?>
  <div class="page-header card">
                                          <div class="card-block">
                                                      <ul class="breadcrumb-title ">
                                                  <li class="breadcrumb-item">
                                                      <a href="<?php echo e(url('/')); ?>"> <i class="fa fa-home"></i> </a>
                                                  </li>
                                                  <li class="breadcrumb-item"><a href="#!">Installment</a>
                                                          </li>
                                                          <li class="breadcrumb-item"><a href="#!">Add Installment</a>
                                                          </li>
                                              </ul>
                                          </div>
                                      </div>


<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">
          <div class="row">
<div class="col-lg-12">
  <?php if(session('status')): ?>
      <div class="alert alert-success">
          <?php echo e(session('status')); ?>

      </div>
  <?php endif; ?>

  <form action="<?php echo e(route('installment_add.submit')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group row">
  <label class="col-sm-2 col-form-label" for="email_hosting_years">Company Name</label>
  <div class="col-sm-10">

    <select id="email_hosting_years" name="select_company_name" class="form-control">
        <option value="" selected >Select Company Name</option>

        <?php $__currentLoopData = $customer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if(!empty($customer_detail->company_name)): ?>

          <option value="<?php echo e($customer_detail->company_name); ?>" ><?php echo e($customer_detail->company_name); ?></option>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </select>
    
  </div>
</div>



    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="quotation">Quotation</label>
        <div class="col-sm-10">
            <input type="text" id="quotation" class="form-control" name="quotation" value="<?php echo e(old('quotation')); ?>" placeholder="Quotation">
        </div>
    </div>



    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="invoice">Invoice</label>
        <div class="col-sm-10">
            <input type="text" id="invoice" class="form-control" name="invoice" value="<?php echo e(old('invoice')); ?>" placeholder="Invoice">

        </div>
    </div>


        <div class="form-group row">
          <label class="col-sm-2 col-form-label" for="services">Services</label>
          <div class="col-sm-10">
            <textarea name="services" id="services"  rows="5" cols="5" class="form-control" placeholder="Services"><?php echo e(old('services')); ?></textarea>
          </div>
        </div>


    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="total_amount">Total Amount</label>
        <div class="col-sm-10">
            <input type="number" id="total_amount" class="form-control" name="total_amount" value="<?php echo e(old('total_amount')); ?>" placeholder="$ Total Amount">
            <?php if($errors->has('total_amount')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('total_amount')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-2 col-form-label" for="installment_duration">Installment Durations</label>
      <div class="col-sm-10">

        <select id="installment_duration" name="installment_duration" class="form-control">
            <option value="1" selected>Monthly</option>
              <option value="0" >Yearly</option>
    </select>
      </div>
    </div>

    

        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="installment_unit">Total Installment Unit</label>
            <div class="col-sm-10">
                <input type="number" id="installment_unit" class="form-control" name="installment_unit" value="<?php echo e(old('installment_unit')); ?>" placeholder="$ Per Years Repayment">
                <?php if($errors->has('installment_unit')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('installment_unit')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="per_unit_repayment">Per Unit Repayment</label>
            <div class="col-sm-10">
                <input type="number" id="per_unit_repayment" class="form-control" name="per_unit_repayment" value="<?php echo e(old('per_unit_repayment')); ?>" placeholder="$ Per Years Repayment">
                <?php if($errors->has('per_unit_repayment')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('per_unit_repayment')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label" for="">Start Date and End Date</label>
          <div class="col-sm-5">
            <div class='input-group date datepicker'>
                            <input type='text' class="form-control" name="installment_start_date" value="<?php echo e(old('installment_start_date')); ?>" placeholder="Start Date" />
                            <?php if($errors->has('installment_start_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('installment_start_date')); ?></strong>
                                </span>
                            <?php endif; ?>
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                      </div>
          <div class="col-sm-5">
            <div class='input-group date datepicker'>
                            <input type='text' class="form-control" name="installment_end_date" value="<?php echo e(old('installment_end_date')); ?>" placeholder="End Date" />
                            <?php if($errors->has('installment_end_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('installment_end_date')); ?></strong>
                                </span>
                            <?php endif; ?>
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                      </div>
        </div>


    <div class="form-group row">
      <label class="col-sm-2 col-form-label"> </label>
      <div class="col-sm-10">
        <button type="submit"  class="btn btn-out-dotted btn-primary btn-square">Add Installment Accounts</button>
      </div>
    </div>



            </form>
          </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_here'); ?>
  <script>
      $(function () {
          $('.datepicker').datepicker({
              format: "yyyy-mm-dd",
              autoclose: true,
              todayHighlight: true,
            showOtherMonths: true,
            selectOtherMonths: true,
            autoclose: true,
            changeMonth: true,
            changeYear: true,
            orientation: "button"
          });
      });

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>